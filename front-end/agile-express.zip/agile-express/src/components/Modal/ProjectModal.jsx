import React, { useState } from 'react'
import './modal.css'

export default function ProjectModal({ addProject, setShowModal }) {

    const [project, setProject] = useState({ id: 1, title: "", content: "", startDate: "", finishDate: "" });

    const submitHandler = e => {
        e.preventDefault();
        addProject(project);
    }

    return (
        <div className="modal-background">
            <div className="modal-container">
                <div className="titleCloseBtn"><button onClick={() => setShowModal(false)}>X</button></div>
                <div className="title"><h3>Add New Project</h3></div>
                <div className="body">
                    <form onSubmit={submitHandler}>
                        <div className="row">
                            <div className="mb-3 col-lg-5">
                                <label>Project Title</label>
                                <input
                                    type="text"
                                    className="form-control"
                                    placeholder="Enter project title"
                                    onChange={e => setProject({ ...project, title: e.target.value })}
                                    value={project.title}
                                />
                            </div>
                            <div className="mb-3 col-lg-7">
                                <label>Project Content</label>
                                <input
                                    type="text"
                                    className="form-control"
                                    placeholder="Enter project content"
                                    onChange={e => setProject({ ...project, content: e.target.value })}
                                    value={project.content}
                                />
                            </div>
                        </div>
                        <div className="row">
                            <div className="mb-3 col-lg-6">
                                <label>Starting Date</label>
                                <input
                                    type="date"
                                    className="form-control"
                                    placeholder="Enter project starting date"
                                    onChange={e => setProject({ ...project, startDate: e.target.value })}
                                    value={project.startDate}
                                />
                            </div>
                            <div className="mb-3 col-lg-6">
                                <label>Finish Date</label>
                                <input
                                    type="date"
                                    className="form-control"
                                    placeholder="Enter project starting date"
                                    onChange={e => setProject({ ...project, finishDate: e.target.value })}
                                    value={project.finishDate}
                                />
                            </div>
                        </div>
                        <div className="d-grid">
                            <button type="submit" className="btn btn-primary">
                                Submit
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    )
}