import React, { useState } from 'react'
import './modal.css'

export default function UpdateSprintModal({ inputSprint, updateSprint, setShowUpdateSprintModal }) {

    const [sprint, setSprint] = useState({ sprintId: inputSprint.sprintId, title: inputSprint.title, content: inputSprint.content, startDate: inputSprint.startDate, finishDate: inputSprint.finishDate });

    const submitHandler = e => {
        e.preventDefault();
        updateSprint(sprint.sprintId, sprint);
    }

    return (
        <div className="modal-background">
            <div className="modal-container-sprint modal-container-sprint-update">
                <div className="titleCloseBtn"><button onClick={() => setShowUpdateSprintModal(false)}>X</button></div>
                <div className="body">
                    <form onSubmit={submitHandler}>
                        <div className="row">
                            <div className="mb-1 col-lg-2">
                                <label>Sprint Title</label>
                                <input
                                    type="text"
                                    className="form-control"
                                    placeholder="Enter sprint title"
                                    onChange={e => setSprint({ ...sprint, title: e.target.value })}
                                    value={sprint.title}
                                />
                            </div>
                            <div className="mb-1 col-lg-4">
                                <label>Sprint Content</label>
                                <input
                                    type="text"
                                    className="form-control"
                                    placeholder="Enter sprint content"
                                    onChange={e => setSprint({ ...sprint, content: e.target.value })}
                                    value={sprint.content}
                                />
                            </div>
                            <div className="mb-1 col-lg-2">
                                <label>Starting Date</label>
                                <input
                                    type="date"
                                    className="form-control"
                                    placeholder="Enter task starting date"
                                    onChange={e => setSprint({ ...sprint, startDate: e.target.value })}
                                    value={sprint.startDate}
                                />
                            </div>
                            <div className="mb-1 col-lg-2">
                                <label>Finish Date</label>
                                <input
                                    type="date"
                                    className="form-control"
                                    placeholder="Enter task starting date"
                                    onChange={e => setSprint({ ...sprint, finishDate: e.target.value })}
                                    value={sprint.finishDate}
                                />
                            </div>
                            <div className="d-grid col-lg-2">
                                <br />
                                <button type="submit" className="btn btn-primary btn-sm">
                                    Update
                            </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    )
}